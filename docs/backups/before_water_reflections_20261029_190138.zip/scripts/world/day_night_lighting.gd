extends CanvasModulate
## Ambient color on the gameplay canvas only; HUD remains in its own CanvasLayer.
## This is a color tint, not expensive dynamic lighting or real-time shadows.

func _ready() -> void:
	color = GameClock.get_lighting_color()
	GameClock.period_changed.connect(_sync_environment, CONNECT_DEFERRED)
	call_deferred("_sync_environment", GameClock.get_period())


func _process(_delta: float) -> void:
	color = GameClock.get_lighting_color()

func _exit_tree() -> void:
	GameClock.stop()

func _sync_environment(period: StringName) -> void:
	# Deferred signals may outlive a scene's removal during travel.
	if not is_inside_tree() or is_queued_for_deletion(): return
	# Adapt the six clock periods to the existing three ambience profiles.
	var region := get_parent()
	if not region.has_method("set_environment_conditions"): return
	var profile := "night" if period in [&"noite", &"madrugada"] else ("afternoon" if period in [&"tarde", &"anoitecendo"] else "morning")
	var weather: Dictionary = get_tree().get_meta("environment_conditions", {})
	region.set_environment_conditions(profile, weather.get("rain", 0.0), weather.get("wind", 1.0), weather.get("fog", 0.0))
