extends SceneTree
const Travel=preload("res://scripts/world/region_travel.gd")
var checks:=0
var failures:=0
func _initialize()->void:call_deferred("run")
func check(ok:bool,msg:String)->void:
	checks+=1
	if not ok:failures+=1
	print("PASS " if ok else "FAIL ",msg)
func settle()->void:
	for i in 5:await physics_frame
func press_e()->void:
	Input.action_press("interact")
	await process_frame
	await process_frame
	Input.action_release("interact")
	await settle()
func run()->void:
	var clearing:Node2D=load(Travel.CLEARING).instantiate()
	root.add_child(clearing)
	current_scene=clearing
	await settle()
	clearing.slimes[0].make_friend()
	clearing.friends_count=1
	clearing.player.position=Vector2(1610,3120)
	await settle()
	check(clearing.hud_hint.text.contains("Viajar"),"Clearing south shows travel prompt")
	await press_e()
	check(current_scene.name=="ValeDasNascentes","E enters Map 2")
	if current_scene.name!="ValeDasNascentes":quit(1);return
	check(current_scene.player.position.is_equal_approx(Vector2(1600,180)),"Arrival stays clear of return trigger")
	current_scene.player.position=Vector2(1600,70)
	await settle()
	check(current_scene.hud_hint.text.contains("Voltar"),"North shows return prompt")
	await press_e()
	check(current_scene.scene_file_path==Travel.CLEARING,"E returns to the existing Map 1 scene")
	check(current_scene.player.position.is_equal_approx(Vector2(1600,2980)),"Return spawn is inside the south trail")
	check(current_scene.friends_count==1 and current_scene.slimes[0].befriended,"Friendship preserved across travel")
	check(not current_scene.slimes[1].befriended,"Unbefriended slimes remain unchanged")
	check(not has_meta("region_arrival"),"Arrival marker consumed once")
	print("REGION_TRAVEL ",checks," checks; ",failures," failures")
	quit(1 if failures else 0)
