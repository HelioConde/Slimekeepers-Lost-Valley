extends "res://scripts/world/clearing_region.gd"
## Runtime for expanded map; legacy clearing remains untouched.
const Forest = preload("res://scripts/world/forest_layout.gd")
var found_places: Dictionary = {}
var ecosystem: Node2D
var habitat_manager: Node2D
var environmental_audio: Node2D
var _last_zone := ""
var _last_water_time := -1.0

func _ready() -> void:
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	y_sort_enabled = true
	player = $Player
	player.position = $SpawnPoints/PlayerSpawn.global_position
	player.world_bounds = Rect2(Vector2(24,44),Forest.WORLD_SIZE-Vector2(48,68))
	var camera: Camera2D = player.get_node("Camera2D")
	camera.limit_left = 0
	camera.limit_top = 0
	camera.limit_right = 6400
	camera.limit_bottom = 6400
	if get_tree().get_meta("region_arrival","") == "clearing_south":
		get_tree().remove_meta("region_arrival")
		player.position = Forest.SOUTH_ARRIVAL
	camera.reset_smoothing()
	found_places = get_tree().get_meta("forest_places",{}).duplicate()
	_create_hud()
	_compact_hud()
	hud_title.text = "FLORESTA DO DESPERTAR"
	_update_hud()
	for area in $Exits.get_children(): area.body_entered.connect(_on_exit_entered.bind(area.name))
	_setup_ecosystem()
	habitat_manager = preload("res://scripts/world/forest_habitats.gd").new()
	habitat_manager.name = "HabitatManager"
	add_child(habitat_manager)
	habitat_manager.slime_spawned.connect(_on_forest_slime)
	var habitats := Forest.habitats()
	for h in habitats:
		h.flower_points = [h.center+Vector2(-60,-45),h.center+Vector2(60,30)]
	habitat_manager.configure(self,player,Forest.SPAWN,habitats)

func _on_forest_slime(slime: Node2D) -> void:
	slimes.append(slime)
	slime.tree_exiting.connect(func(): slimes.erase(slime))
	_update_hud()

func _setup_ecosystem() -> void:
	var flowers: Array[Vector2] = []
	for at in get_meta("flower_points",PackedVector2Array()): flowers.append(at)
	var water: Array[Vector2] = []
	for at in get_meta("water_points",PackedVector2Array()): water.append(at)
	ecosystem = preload("res://scripts/world/forest_life.gd").new()
	ecosystem.name = "ForestLife"
	ecosystem.configure(player,flowers,water)
	ecosystem.open_area_test = func(at:Vector2)->bool: return Forest.open_area(at)
	var leaves: Array[Vector2] = []
	for group in [$VegetationHigh,$ExpandedForest]:
		for prop in group.get_children():
			if prop.has_node("Sprite") and prop.visible:
				prop.get_node("Sprite").material = ecosystem.shared_wind_material
				leaves.append(prop.global_position+Vector2(0,-70))
	for prop in $FlowerClusters.get_children():
		if prop.has_node("Sprite") and (str(prop.name).begins_with("Wildflowers") or str(prop.name).begins_with("Fern") or str(prop.name).begins_with("Shrub")):
			prop.get_node("Sprite").material = ecosystem.shared_wind_material
	ecosystem.configure_leaf_sources(leaves)
	add_child(ecosystem)
	if ResourceLoader.exists("res://scripts/world/forest_audio.gd"):
		environmental_audio = load("res://scripts/world/forest_audio.gd").new()
		environmental_audio.configure(player,water,Forest.zone)
		add_child(environmental_audio)

func _process(delta: float) -> void:
	# The base world manages interaction/friendship; skip legacy map exit coordinates.
	var water_time: float = ecosystem.shared_wind_material.get_shader_parameter("wind_time")
	if water_time != _last_water_time:
		_last_water_time = water_time
		$SouthernBrook/Water.material.set_shader_parameter("elapsed",water_time)
	var zone_name := Forest.zone(player.position)
	if zone_name != _last_zone:
		_last_zone = zone_name
		hud_title.text = zone_name.to_upper()
	if message_time > 0:
		message_time -= delta
		if message_time <= 0: popup.text = ""
	var closest := _closest_slime()
	if closest != null:
		hud_hint.text = "[E] Fazer amizade com "+closest.display_name() if not closest.befriended else "[E] Cumprimentar "+closest.display_name()
		if Input.is_action_just_pressed("interact"):
			if not closest.befriended:
				closest.make_friend()
				_update_hud()
			_notify(closest.display_name()+" parece feliz com sua visita.")
		return
	hud_hint.text = "WASD / setas · explorar    Shift · correr    E · interagir"
	if player.position.distance_to(Forest.SOUTH_EXIT)<115:
		hud_hint.text = "[E] Viajar para o Vale das Nascentes"
		if Input.is_action_just_pressed("interact"):
			get_tree().set_meta("forest_places",found_places.duplicate())
			var travel = preload("res://scripts/world/region_travel.gd")
			travel.travel(self,travel.VALLEY,"valley_north")
		return
	var spring := get_node("NaturalSpring")
	if spring.can_examine(player.global_position):
		hud_hint.text = "[E] Examinar lago"
		if Input.is_action_just_pressed("interact"): _notify("Um pequeno lago de água cristalina repousa entre as árvores.")
		return
	for marker in $PointsOfInterest.get_children():
		if marker.position.distance_to(player.position)<100:
			hud_hint.text = "[E] Observar · "+marker.get_meta("title")
			if Input.is_action_just_pressed("interact"):
				found_places[str(marker.name)] = true
				_notify(marker.get_meta("description"))
				_update_hud()
			return

func _update_hud() -> void:
	if hud_goal == null: return
	# Count identities rather than spawn events: a restored friend remains one friend.
	friends_count = 0
	for befriended in get_tree().get_meta("forest_slime_friends",{}).values():
		if befriended: friends_count += 1
	hud_goal.text = "Amizades %d/8 · recantos %d/8" % [friends_count,found_places.size()]

func _on_exit_entered(body: Node2D, exit_name: StringName) -> void:
	if body != player or _visited_exits.has(exit_name): return
	_visited_exits[exit_name] = true
	var messages := {"North":"A Mata Antiga segue pelas colinas. Explore os caminhos ao redor.","East":"O Refúgio Verde se espalha pelos bosques floridos.","South":"Vale das Nascentes · pressione E para seguir pelas águas."}
	_notify(messages[str(exit_name)])
