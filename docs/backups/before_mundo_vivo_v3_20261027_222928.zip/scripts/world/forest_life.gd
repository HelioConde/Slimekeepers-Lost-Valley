extends Node2D
## Camera-local forest decoration. All points are global coordinates.
## configure() before add_child(); share shared_wind_material with Sprite2D plants.
## Provide open_area_test(global_point) for ground bird shadows; absent = no birds.
const WIND = preload("res://scripts/world/forest_wind.gdshader")
const STEP := 0.125
const BUCKET_SIZE := 256.0
const MAX_BUTTERFLIES := 4
const MAX_LEAVES := 8
const COLORS := [Color("f6e799"), Color("eef1cd"), Color("add9e8"), Color("e9b8ce")]

var shared_wind_material := ShaderMaterial.new()
var open_area_test: Callable
var _player: Node2D
var _flower_buckets: Dictionary = {}
var _leaf_buckets: Dictionary = {}
var _local_flowers: Array[Vector2] = []
var _local_leaf_sources: Array[Vector2] = []
var _butterflies: Array[Dictionary] = []
var _leaves: Array[Dictionary] = []
var _rng := RandomNumberGenerator.new()
var _reduced_motion := false
var _age := 0.0
var _accumulator := 0.0
var _refresh := 0.0
var _view := Rect2()
var _bird_timer := 0.0
var _bird_remaining := 0.0
var _bird_start := Vector2.ZERO
var _bird_end := Vector2.ZERO
var _bird_events := 0
var _last_bird_interval := 0.0
var _updates := 0
var _ground_shadows: Node2D

func _init() -> void:
	shared_wind_material.shader = WIND
	_rng.seed = 271026
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST

func configure(player: Node2D, flower_points: Array[Vector2], _water_points: Array[Vector2] = []) -> void:
	_player = player
	_flower_buckets.clear()
	for point in flower_points:
		var key := Vector2i(floori(point.x / BUCKET_SIZE), floori(point.y / BUCKET_SIZE))
		if not _flower_buckets.has(key):
			_flower_buckets[key] = []
		_flower_buckets[key].append(point)
	_butterflies.clear()
	_leaves.clear()
	_refresh = 0.0

func configure_leaf_sources(points: Array[Vector2]) -> void:
	_leaf_buckets.clear()
	for point in points:
		var key := Vector2i(floori(point.x / BUCKET_SIZE), floori(point.y / BUCKET_SIZE))
		if not _leaf_buckets.has(key):
			_leaf_buckets[key] = []
		_leaf_buckets[key].append(point)
	_refresh = 0.0

func _ready() -> void:
	z_index = 5
	_ground_shadows = Node2D.new()
	_ground_shadows.name = "BirdGroundShadow"
	_ground_shadows.z_as_relative = false
	_ground_shadows.z_index = -1
	_ground_shadows.draw.connect(_draw_bird_shadow)
	add_child(_ground_shadows)
	var settings := ConfigFile.new()
	if settings.load("user://presentation.cfg") == OK:
		_reduced_motion = bool(settings.get_value("accessibility", "reduce_motion", false))
	_refresh_local_effects()
	_schedule_bird()
	_update_wind()
	queue_redraw()
	_ground_shadows.queue_redraw()

func set_reduced_motion(enabled: bool) -> void:
	_reduced_motion = enabled
	if enabled:
		_bird_remaining = 0.0
		_leaves.clear()
	_refresh = 0.0
	_update_wind()
	queue_redraw()
	if is_instance_valid(_ground_shadows):
		_ground_shadows.queue_redraw()

func _process(delta: float) -> void:
	_accumulator += delta
	if _accumulator < STEP:
		return
	# Advance only once after a stall: avoid bursts of ambient events during catch-up.
	var elapsed := minf(_accumulator, 0.25)
	_accumulator = fmod(_accumulator, STEP)
	_updates += 1
	_refresh -= elapsed
	if _refresh <= 0.0:
		_refresh_local_effects()
		_refresh = 0.5
	if not _reduced_motion:
		_age += elapsed
		_step_butterflies(elapsed)
		_step_leaves(elapsed)
		_step_bird(elapsed)
	_update_wind()
	queue_redraw()
	_ground_shadows.queue_redraw()

func _camera_rect() -> Rect2:
	var center := _player.global_position if is_instance_valid(_player) else global_position
	var size := get_viewport_rect().size
	var camera := get_viewport().get_camera_2d()
	if is_instance_valid(camera):
		center = camera.get_screen_center_position()
		size /= camera.zoom
	if size.x < 16.0 or size.y < 16.0:
		size = Vector2(960, 540)
	return Rect2(center - size * 0.5, size)

func _refresh_local_effects() -> void:
	_view = _camera_rect()
	var area := _view.grow(80.0)
	_local_flowers.clear()
	_local_leaf_sources.clear()
	var first := Vector2i(floori(area.position.x / BUCKET_SIZE), floori(area.position.y / BUCKET_SIZE))
	var last := Vector2i(floori(area.end.x / BUCKET_SIZE), floori(area.end.y / BUCKET_SIZE))
	for y in range(first.y, last.y + 1):
		for x in range(first.x, last.x + 1):
			for point: Vector2 in _flower_buckets.get(Vector2i(x, y), []):
				if area.has_point(point):
					_local_flowers.append(point)
			for point: Vector2 in _leaf_buckets.get(Vector2i(x, y), []):
				if area.has_point(point):
					_local_leaf_sources.append(point)
	for index in range(_butterflies.size() - 1, -1, -1):
		if not area.has_point(_butterflies[index].position) or _local_flowers.is_empty():
			_butterflies.remove_at(index)
	var desired := mini(MAX_BUTTERFLIES, _local_flowers.size() + 1) if not _local_flowers.is_empty() else 0
	while _butterflies.size() < desired:
		var target: Vector2 = _local_flowers[_rng.randi_range(0, _local_flowers.size() - 1)]
		_butterflies.append({"position": target, "start": target, "target": target, "time": 0.0,
			"duration": _rng.randf_range(1.5, 4.0), "landed": true, "phase": _rng.randf_range(0, TAU), "fade": 0.0})
	for index in range(_leaves.size() - 1, -1, -1):
		if not area.has_point(_leaves[index].start):
			_leaves.remove_at(index)

func _step_butterflies(delta: float) -> void:
	for butterfly in _butterflies:
		butterfly.fade = minf(1.0, float(butterfly.fade) + delta * 0.5)
		butterfly.time += delta
		if butterfly.time >= butterfly.duration:
			butterfly.time = 0.0
			butterfly.landed = not butterfly.landed
			butterfly.start = butterfly.position
			if butterfly.landed:
				butterfly.position = butterfly.target
				butterfly.duration = _rng.randf_range(2.0, 4.0)
			else:
				var nearby: Array[Vector2] = []
				for point in _local_flowers:
					if point.distance_squared_to(butterfly.position) < 240.0 * 240.0:
						nearby.append(point)
				if not nearby.is_empty():
					butterfly.target = nearby[_rng.randi_range(0, nearby.size() - 1)]
				butterfly.duration = _rng.randf_range(3.5, 6.0)
		if not butterfly.landed:
			var progress := clampf(float(butterfly.time) / float(butterfly.duration), 0.0, 1.0)
			var arc := Vector2(sin(progress * TAU + float(butterfly.phase)) * 15.0, -sin(progress * PI) * 24.0)
			butterfly.position = (butterfly.start as Vector2).lerp(butterfly.target, smoothstep(0.0, 1.0, progress)) + arc * sin(progress * PI)

func _step_leaves(delta: float) -> void:
	for index in range(_leaves.size() - 1, -1, -1):
		_leaves[index].age += delta
		if _leaves[index].age >= _leaves[index].duration:
			_leaves.remove_at(index)
	# On average one isolated leaf every two seconds, with an absolute pool cap.
	if not _local_leaf_sources.is_empty() and _leaves.size() < MAX_LEAVES and _rng.randf() < delta * 0.5:
		var origin: Vector2 = _local_leaf_sources[_rng.randi_range(0, _local_leaf_sources.size() - 1)]
		_leaves.append({"start": origin, "age": 0.0, "duration": _rng.randf_range(4.0, 7.0), "phase": _rng.randf_range(0, TAU)})

func _schedule_bird() -> void:
	_last_bird_interval = _rng.randf_range(25.0, 60.0)
	_bird_timer = _last_bird_interval

func _step_bird(delta: float) -> void:
	_bird_remaining = maxf(0.0, _bird_remaining - delta)
	_bird_timer -= delta
	if _bird_timer > 0.0:
		return
	_schedule_bird()
	if not open_area_test.is_valid() or not bool(open_area_test.call(_view.get_center())):
		return
	_bird_start = _view.position + Vector2(-24, _view.size.y * _rng.randf_range(0.15, 0.65))
	_bird_end = _bird_start + Vector2(_view.size.x + 48.0, _view.size.y * 0.3)
	_bird_remaining = 3.5
	_bird_events += 1

func _update_wind() -> void:
	shared_wind_material.set_shader_parameter("wind_time", _age)
	shared_wind_material.set_shader_parameter("wind_strength", 0.0 if _reduced_motion else 0.85 + sin(_age * 0.11) * 0.3)
	shared_wind_material.set_shader_parameter("wind_direction", Vector2(1.0, sin(_age * 0.07) * 0.3))
	shared_wind_material.set_shader_parameter("active_center", _view.get_center())
	shared_wind_material.set_shader_parameter("active_half_size", _view.size * 0.5)

func debug_snapshot() -> Dictionary:
	var landed := 0
	for butterfly in _butterflies:
		if butterfly.landed:
			landed += 1
	return {"butterflies": _butterflies.size(), "landed": landed, "leaves": _leaves.size(),
		"birds": int(_bird_remaining > 0.0), "bird_events": _bird_events,
		"last_bird_interval": _last_bird_interval, "animation_time": _age,
		"updates": _updates, "local_flowers": _local_flowers.size(), "reduced_motion": _reduced_motion}

func _draw_bird_shadow() -> void:
	if _bird_remaining > 0.0:
		var progress := 1.0 - _bird_remaining / 3.5
		var global_point := _bird_start.lerp(_bird_end, progress)
		if not open_area_test.is_valid() or not bool(open_area_test.call(global_point)):
			return
		var point := to_local(global_point).round()
		var shade := Color(0.10, 0.16, 0.19, sin(progress * PI) * 0.16)
		_ground_shadows.draw_rect(Rect2(point + Vector2(-2, -4), Vector2(4, 11)), shade)
		var lift := roundf(sin(_age * 6.0) * 3.0)
		for side in [-1.0, 1.0]:
			_ground_shadows.draw_rect(Rect2(point + Vector2(side * 5.0 - 3.0, lift), Vector2(6, 3)), shade)
			_ground_shadows.draw_rect(Rect2(point + Vector2(side * 10.0 - 2.0, lift - 2.0), Vector2(4, 2)), shade)

func _draw() -> void:
	for leaf in _leaves:
		var progress := float(leaf.age) / float(leaf.duration)
		var at := to_local(leaf.start + Vector2(progress * 40.0 + sin(progress * TAU + float(leaf.phase)) * 9.0, progress * 60.0)).round()
		var tint := Color(0.69, 0.71, 0.32, sin(progress * PI) * 0.65)
		draw_rect(Rect2(at, Vector2(3, 2)), tint)
		draw_rect(Rect2(at + Vector2(1, -1), Vector2(2, 3)), tint)
	for index in _butterflies.size():
		var butterfly: Dictionary = _butterflies[index]
		var point := to_local(butterfly.position).round()
		var wings := 1.0 if _reduced_motion else (2.0 if sin(_age * (2.0 if butterfly.landed else 15.0) + float(butterfly.phase)) > 0.0 else 1.0)
		var tint: Color = COLORS[index % COLORS.size()]
		tint.a = 1.0 if _reduced_motion else float(butterfly.fade)
		draw_rect(Rect2(point + Vector2(-wings - 1, -1), Vector2(wings, 3)), tint)
		draw_rect(Rect2(point + Vector2(1, -1), Vector2(wings, 3)), tint)
		draw_rect(Rect2(point, Vector2(1, 3)), Color(0.25, 0.27, 0.19, tint.a))
