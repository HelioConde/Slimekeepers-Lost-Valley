extends "res://scripts/world/clearing_region.gd"
const Valley = preload("res://scripts/world/valley_layout.gd")
const Travel = preload("res://scripts/world/region_travel.gd")
var elapsed := 0.0
var reduce_motion := false
var found_zones: Dictionary = {}

func _ready() -> void:
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	y_sort_enabled = true
	player = $Player
	player.position = Valley.SPAWN
	player.world_bounds = Rect2(24,44,3152,3132)
	var camera: Camera2D = player.get_node("Camera2D")
	camera.limit_right = 3200
	camera.limit_bottom = 3200
	camera.reset_smoothing()
	_create_hud()
	_compact_hud()
	hud_title.text = "VALE DAS NASCENTES"
	found_zones = get_tree().get_meta("valley_discoveries",{}).duplicate()
	hud_goal.text = "Siga as águas e explore as margens" if found_zones.is_empty() else "Recantos descobertos: %d / 5" % found_zones.size()
	var cfg := ConfigFile.new()
	if cfg.load("user://presentation.cfg") == OK:
		reduce_motion = cfg.get_value("accessibility","reduce_motion",false)
	if has_node("UnderwaterLife"):$UnderwaterLife.set_reduced_motion(reduce_motion)
	for fall in $Waterfalls.get_children():
		var life:=fall.get_node_or_null("LivingFoam")
		if life:life.set_reduced_motion(reduce_motion)
	if get_tree().has_meta("region_arrival"): get_tree().remove_meta("region_arrival")

func _process(delta: float) -> void:
	elapsed += delta
	if message_time > 0:
		message_time -= delta
		if message_time <= 0: popup.text = ""
	hud_hint.text = "WASD / Setas: andar   •   Shift: correr   •   E: observar"
	for marker: Marker2D in $PointsOfInterest.get_children():
		if player.position.distance_to(marker.position)<90:
			hud_hint.text = "[E] " + str(marker.get_meta("label"))
			if Input.is_action_just_pressed("interact"):
				_notify(marker.get_meta("description"))
				found_zones[marker.name] = true
				hud_goal.text = "Recantos descobertos: %d / 5" % found_zones.size()
	if player.position.distance_to(Vector2(1600,70)) < 100:
		hud_hint.text = "[E] Voltar à Floresta do Despertar"
		if Input.is_action_just_pressed("interact"):
			Travel.travel(self,Travel.CLEARING,"clearing_south")
			return
	elif player.position.distance_to(Vector2(1780,3160)) < 100:
		hud_hint.text = "[E] Observar o caminho ao sul"
		if Input.is_action_just_pressed("interact"):
			_notify("O caminho segue pela ilha. Uma nova região chegará em breve.")
	if not reduce_motion:
		for water: Polygon2D in $Water.get_children():
			if water.material is ShaderMaterial:
				water.material.set_shader_parameter("elapsed",floor(elapsed*8)/8)
		if has_node("WaterBankTiles"):
			$WaterBankTiles.material.set_shader_parameter("elapsed",floor(elapsed*8)/8)
		for fall: Node2D in $Waterfalls.get_children():
			fall.get_node("Cascade").material.set_shader_parameter("elapsed",floor(elapsed*8)/8)
