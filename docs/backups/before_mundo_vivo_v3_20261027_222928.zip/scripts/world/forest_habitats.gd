extends Node2D
## Bounded, deterministic habitat slots. Coordinates are in world space.
signal slime_spawned(slime: Node2D)
const SLIME_SCRIPT := preload("res://scripts/world/forest_slime.gd")
const EXCLUSION_RADIUS := 960.0
const BODY_RADIUS := 12.0
const MIN_SEPARATION := 50.0
const RESPAWN_COOLDOWN := 20.0
const MAX_POPULATION := 10
const WORLD_BOUNDS := Rect2(32, 32, 6336, 6336)

var spawned: Array[Node2D] = []
var habitats: Array[Dictionary] = []
var region: Node2D
var player: Node2D
var player_spawn := Vector2(3200, 3200)
var _slots: Dictionary = {}
var _retry_at: Dictionary = {}
var _elapsed := 0.0
var _check_timer := 0.0
var _body_shape := CapsuleShape2D.new()
var _configured := false
var _initial_camera_rect := Rect2()
var _physics_warmup := 2

func configure(owner_region: Node2D, owner_player: Node2D, spawn: Vector2, habitat_data: Array[Dictionary]) -> void:
	if _configured:
		return
	_configured = true
	region = owner_region
	player = owner_player
	player_spawn = spawn
	habitats = habitat_data.duplicate(true)
	_body_shape.radius = BODY_RADIUS
	_body_shape.height = 28.0
	var half_view := Vector2(640, 360)
	if is_instance_valid(player):
		var camera := player.get_node_or_null("Camera2D") as Camera2D
		if camera != null:
			half_view = get_viewport_rect().size / camera.zoom / 2.0
	_initial_camera_rect = Rect2(player_spawn - half_view, half_view * 2.0).grow(64.0)
	set_physics_process(true)

func _physics_process(_delta: float) -> void:
	# Region props are built synchronously; wait until physics has registered them.
	if not _configured:
		return
	_physics_warmup -= 1
	if _physics_warmup <= 0:
		set_physics_process(false)
		call_deferred("populate")

func _process(delta: float) -> void:
	_elapsed += delta
	_check_timer -= delta
	if _check_timer <= 0.0 and _configured:
		_check_timer = 1.0
		# Only attempt missing slots after the initial population has run.
		if _elapsed >= RESPAWN_COOLDOWN:
			populate()

func populate() -> void:
	if not _configured or not is_instance_valid(region) or not region.is_inside_tree():
		return
	for index in range(spawned.size() - 1, -1, -1):
		if not is_instance_valid(spawned[index]) or spawned[index].is_queued_for_deletion():
			spawned.remove_at(index)
	for habitat: Dictionary in habitats:
		var habitat_id := str(habitat.get("id", ""))
		if habitat_id.is_empty():
			continue
		for index in clampi(int(habitat.get("population", 2)), 0, MAX_POPULATION):
			var persistent_id := "brotinho/%s/%d" % [habitat_id, index]
			if is_instance_valid(_slots.get(persistent_id)):
				continue
			if spawned.size() >= MAX_POPULATION or _elapsed < float(_retry_at.get(persistent_id, -1.0)):
				continue
			_retry_at[persistent_id] = _elapsed + RESPAWN_COOLDOWN
			var rng := RandomNumberGenerator.new()
			rng.seed = hash(persistent_id)
			for attempt in 48:
				var center: Vector2 = habitat.get("center", Vector2.ZERO)
				var radius := maxf(0.0, float(habitat.get("radius", 200.0)) - BODY_RADIUS - 16.0)
				var candidate := center + Vector2.from_angle(rng.randf_range(0.0, TAU)) * sqrt(rng.randf()) * radius
				if not is_position_allowed(candidate, habitat) or _in_current_view(candidate):
					continue
				var slime: Node2D = SLIME_SCRIPT.new()
				slime.configure(self, player, habitat, persistent_id)
				region.add_child(slime)
				slime.global_position = candidate
				_slots[persistent_id] = slime
				spawned.append(slime)
				slime.tree_exiting.connect(_on_slime_exiting.bind(persistent_id))
				slime_spawned.emit(slime)
				break

func _on_slime_exiting(persistent_id: String) -> void:
	_slots.erase(persistent_id)
	_retry_at[persistent_id] = _elapsed + RESPAWN_COOLDOWN

func is_position_allowed(point: Vector2, habitat: Dictionary, ignore: Node2D = null) -> bool:
	if not WORLD_BOUNDS.has_point(point) or point.distance_to(player_spawn) < EXCLUSION_RADIUS + BODY_RADIUS:
		return false
	if _initial_camera_rect.has_point(point):
		return false
	var center: Vector2 = habitat.get("center", Vector2.ZERO)
	if point.distance_to(center) > maxf(0.0, float(habitat.get("radius", 200.0)) - BODY_RADIUS):
		return false
	for slime: Node2D in spawned:
		if is_instance_valid(slime) and slime != ignore and point.distance_to(slime.global_position) < MIN_SEPARATION:
			return false
	var query := PhysicsShapeQueryParameters2D.new()
	query.shape = _body_shape
	query.transform = Transform2D(0.0, point + Vector2(0, -10))
	query.collision_mask = 2
	query.collide_with_areas = false
	return region.get_world_2d().direct_space_state.intersect_shape(query, 1).is_empty()

func _in_current_view(point: Vector2) -> bool:
	if not is_instance_valid(player):
		return false
	var camera := player.get_node_or_null("Camera2D") as Camera2D
	if camera == null:
		return point.distance_to(player.global_position) < 360.0
	var half_view := get_viewport_rect().size / camera.zoom / 2.0
	return Rect2(camera.get_screen_center_position() - half_view, half_view * 2.0).grow(96.0).has_point(point)
