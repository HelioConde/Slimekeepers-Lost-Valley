extends CharacterBody2D
## Peaceful Brotinho: idle, short hops, flowers, curiosity and a bounded retreat.
signal friendship_started(persistent_id: String)
const FRAMES: SpriteFrames = preload("res://assets/slimes/bestiary/brotinho/brotinho_frames.tres")
const WALK_SPEED := 30.0
const ACTIVE_DISTANCE := 1000.0

var slime_type := "brotinho"
var persistent_id := ""
var befriended := false
var habitat: Dictionary = {}
var sprite: AnimatedSprite2D
var manager: Node2D
var player: Node2D
var behavior := "idle"
var _rng := RandomNumberGenerator.new()
var _target := Vector2.ZERO
var _decision_time := 1.0
var _happy_time := 0.0
var _hop_time := 0.0

func configure(habitat_manager: Node2D, observed_player: Node2D, habitat_data: Dictionary, instance_id: String) -> void:
	manager = habitat_manager
	player = observed_player
	habitat = habitat_data
	persistent_id = instance_id
	_rng.seed = hash(persistent_id)
	_decision_time = _rng.randf_range(1.5, 4.0)
	name = "Brotinho_%s" % persistent_id.replace("/", "_")

func _ready() -> void:
	collision_layer = 0
	collision_mask = 2
	motion_mode = CharacterBody2D.MOTION_MODE_FLOATING
	var collision := CollisionShape2D.new()
	var capsule := CapsuleShape2D.new()
	capsule.radius = 12.0
	capsule.height = 28.0
	collision.shape = capsule
	collision.position = Vector2(0, -10)
	add_child(collision)
	sprite = AnimatedSprite2D.new()
	sprite.name = "AnimatedSprite2D"
	sprite.sprite_frames = FRAMES
	sprite.position = Vector2(0, -18)
	sprite.scale = Vector2.ONE * 0.86
	sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	add_child(sprite)
	var friends: Dictionary = get_tree().get_meta("forest_slime_friends", {})
	befriended = bool(friends.get(persistent_id, false))
	sprite.play("idle")

func display_name() -> String:
	return "Brotinho"

func make_friend() -> bool:
	if befriended:
		return false
	befriended = true
	var friends: Dictionary = get_tree().get_meta("forest_slime_friends", {})
	friends[persistent_id] = true
	get_tree().set_meta("forest_slime_friends", friends)
	_happy_time = 2.4
	behavior = "idle"
	sprite.play("happy")
	friendship_started.emit(persistent_id)
	return true

func _physics_process(delta: float) -> void:
	_happy_time = maxf(0.0, _happy_time - delta)
	if not is_instance_valid(player) or not is_instance_valid(manager):
		return
	if global_position.distance_squared_to(player.global_position) > ACTIVE_DISTANCE * ACTIVE_DISTANCE:
		behavior = "idle"
		velocity = Vector2.ZERO
		_idle_animation()
		return
	_decision_time -= delta
	if _happy_time > 0.0:
		return
	if _decision_time <= 0.0:
		_choose_behavior()
	if behavior in ["wander", "flowers", "cautious"]:
		if global_position.distance_to(_target) <= 6.0 or not move_toward_point(_target, delta):
			behavior = "idle"
			_decision_time = _rng.randf_range(1.0, 3.0)
			_idle_animation()
	else:
		_idle_animation()

func _choose_behavior() -> void:
	_decision_time = _rng.randf_range(2.0, 4.5)
	var distance := global_position.distance_to(player.global_position)
	var player_velocity := Vector2.ZERO
	if player is CharacterBody2D:
		player_velocity = (player as CharacterBody2D).velocity
	if distance < 140.0 and player_velocity.length() > 175.0 and player_velocity.dot(global_position - player.global_position) > 0.0:
		var retreat := global_position + player.global_position.direction_to(global_position) * 72.0
		if manager.is_position_allowed(retreat, habitat, self):
			_target = retreat
			behavior = "cautious"
			return
	if distance < 210.0:
		behavior = "curious"
		sprite.flip_h = player.global_position.x < global_position.x
		return
	if _rng.randf() < 0.4:
		behavior = "idle"
		return
	var candidate := global_position + Vector2.from_angle(_rng.randf_range(0.0, TAU)) * _rng.randf_range(35.0, 90.0)
	var flower_points: Array = habitat.get("flower_points", [])
	var interested := not flower_points.is_empty() and _rng.randf() < 0.55
	if interested:
		candidate = flower_points[_rng.randi_range(0, flower_points.size() - 1)] + Vector2.from_angle(_rng.randf_range(0.0, TAU)) * 24.0
	if manager.is_position_allowed(candidate, habitat, self):
		_target = candidate
		behavior = "flowers" if interested else "wander"
	else:
		behavior = "idle"

func move_toward_point(target: Vector2, delta: float) -> bool:
	var direction := global_position.direction_to(target)
	var step := direction * minf(WALK_SPEED * delta, global_position.distance_to(target))
	# Check the capsule endpoint, then sweep the whole motion against real props.
	if not manager.is_position_allowed(global_position + step, habitat, self):
		velocity = Vector2.ZERO
		return false
	velocity = direction * WALK_SPEED
	var hit := move_and_collide(step)
	sprite.flip_h = direction.x < 0.0
	if sprite.animation != &"move":
		sprite.play("move")
	_hop_time += delta
	sprite.position.y = -18.0 - absf(sin(_hop_time * 7.0)) * 2.0
	return hit == null

func _idle_animation() -> void:
	velocity = Vector2.ZERO
	sprite.position.y = -18.0
	var animation := &"happy" if _happy_time > 0.0 else &"idle"
	if sprite.animation != animation:
		sprite.play(animation)
