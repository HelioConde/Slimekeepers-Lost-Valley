extends Node2D
## Broken stepped arcs are clipped to the actual connected water outline.
@export var shores:Array[PackedVector2Array]=[]
@export var width:=48.0
var elapsed:=0.0
var reduce_motion:=false
var frame:=-1
func set_reduced_motion(value:bool) -> void:
	reduce_motion=value
	set_process(not value)
	queue_redraw()
func _process(delta:float) -> void:
	if reduce_motion:return
	elapsed+=delta
	var next:=int(elapsed*8)
	if next!=frame:
		frame=next
		queue_redraw()
func is_water(at:Vector2) -> bool:
	for shore in shores:
		if Geometry2D.is_point_in_polygon(at,shore):return true
	return false
func ripple_pixels(time:float) -> PackedVector2Array:
	var pixels:=PackedVector2Array()
	for ring in 3:
		var progress:=fposmod(time*.22+ring/3.0,1.0)
		var radius:=width*.75+progress*65
		for step in range(2,29):
			if (step+ring)%7<2:continue
			var a:=PI*step/30.0
			var p:Vector2=Vector2(cos(a)*radius,108+sin(a)*(9+progress*25)).snapped(Vector2(2,2))
			if is_water(p+get_parent().position) and is_water(p+get_parent().position+Vector2(6,2)):pixels.append(p)
	return pixels
func _draw() -> void:
	var time:=floorf(elapsed*8)/8
	for p in ripple_pixels(time):draw_rect(Rect2(p,Vector2(6,2)),Color(.63,.87,.81,.46))
	for i in 24:
		var cycle:=fposmod(time*.75+i*.137,1.0)
		var x:=sin(i*7.13)*width
		var p:=Vector2(x,99+cos(i*3.4)*6+cycle*12).snapped(Vector2(2,2))
		if is_water(p+get_parent().position):draw_rect(Rect2(p,Vector2(4+i%3*2,2)),Color(.76,.94,.87,.7*(1.0-cycle)))
	for i in 9:
		var cycle:=fposmod(time*.9+i*.173,1.0)
		var p:=Vector2(sin(i*4.7)*(width-8),100-sin(cycle*PI)*16).snapped(Vector2(2,2))
		if is_water(p+get_parent().position):draw_rect(Rect2(p,Vector2(2,4)),Color(.79,.97,.91,.65*(1.0-cycle)))
